package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.text.InputType
import android.widget.*
import java.security.MessageDigest

class MainActivity : Activity() {
    private lateinit var p: SharedPreferences
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = getSharedPreferences("j", MODE_PRIVATE)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
        if (!Settings.canDrawOverlays(this))
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))

        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        status = TextView(this).apply { textSize = 22f }
        val power = Button(this).apply { text = "Power on / off (password)"; setOnClickListener { power() } }
        val key = EditText(this).apply { hint = "Claude API key (optional)"; setText(p.getString("key", "")) }
        val save = Button(this).apply {
            text = "Save key"
            setOnClickListener { p.edit().putString("key", key.text.toString().trim()).apply(); toast("Saved") }
        }
        val chg = Button(this).apply { text = "Change password"; setOnClickListener { change() } }
        listOf(status, power, key, save, chg).forEach { box.addView(it) }
        setContentView(box)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        status.text = if (JarvisService.running) "Jarvis: ONLINE" else "Jarvis: OFFLINE"
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun sha(s: String) = MessageDigest.getInstance("SHA-256")
        .digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun askPass(title: String, ok: (String) -> Unit) {
        val e = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this).setTitle(title).setView(e)
            .setPositiveButton("OK") { _, _ -> ok(e.text.toString()) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun power() {
        val saved = p.getString("pw", null)
        if (saved == null) {
            askPass("Create a password") { p.edit().putString("pw", sha(it)).apply(); toast("Password set") }
            return
        }
        askPass("Enter password") {
            if (sha(it) == saved) {
                val i = Intent(this, JarvisService::class.java)
                if (JarvisService.running) stopService(i) else startForegroundService(i)
                Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 700)
            } else toast("Access denied")
        }
    }

    private fun change() {
        val saved = p.getString("pw", null) ?: return toast("Set a password first")
        askPass("Current password") { old ->
            if (sha(old) == saved) askPass("New password") {
                p.edit().putString("pw", sha(it)).apply(); toast("Password changed")
            } else toast("Access denied")
        }
    }
}