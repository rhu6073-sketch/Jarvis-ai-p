package com.example.jarvis

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

class JarvisService : Service(), TextToSpeech.OnInitListener {
    companion object { @Volatile var running = false }

    private lateinit var tts: TextToSpeech
    private var sr: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var speaking = false

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        running = true
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "jarvis").setContentTitle("Jarvis is online")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        tts.language = Locale.UK
        tts.setPitch(0.75f)          // deeper, butler-like
        tts.setSpeechRate(0.88f)     // calm and measured
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { speaking = true }
            override fun onDone(id: String?) { speaking = false; h.post { listen() } }
            @Deprecated("") override fun onError(id: String?) { speaking = false; h.post { listen() } }
        })
        say("Good day, sir. Jarvis at your service.")
    }

    private fun say(t: String) {
        h.removeCallbacksAndMessages(null)
        sr?.cancel()
        speaking = true
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    // ---------- Listening ----------
    private val rl = object : RecognitionListener {
        override fun onResults(r: Bundle) {
            val t = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()?.lowercase() ?: ""
            if ("jarvis" in t) {
                val c = t.substringAfter("jarvis").trim()
                if (c.isEmpty()) say("Yes, sir?") else handle(c)
            } else h.postDelayed({ listen() }, 300)
        }
        override fun onError(e: Int) {
            h.postDelayed({ listen() }, if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 600)
        }
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(p: Bundle?) {}
        override fun onEvent(t: Int, p: Bundle?) {}
    }

    private fun listen() {
        if (speaking || !running) return
        if (sr == null) {
            sr = SpeechRecognizer.createSpeechRecognizer(this)
            sr!!.setRecognitionListener(rl)
        }
        sr!!.cancel()
        sr!!.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
        })
    }

    // ---------- Offline commands first ----------
    private fun handle(c: String) {
        when {
            c.startsWith("open ") || c.startsWith("launch ") -> openApp(c.substringAfter(" ").trim())
            "what time" in c || "the time" in c ->
                say("It is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()) + ", sir.")
            "what date" in c || "what day" in c ->
                say("Today is " + SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()) + ", sir.")
            "battery" in c -> {
                val b = getSystemService(BatteryManager::class.java)
                    .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                say("Battery stands at $b percent, sir.")
            }
            "torch" in c || "flashlight" in c -> torch("off" !in c)
            "volume up" in c -> vol(AudioManager.ADJUST_RAISE)
            "volume down" in c -> vol(AudioManager.ADJUST_LOWER)
            c.startsWith("search ") -> {
                val q = c.removePrefix("search for ").removePrefix("search ")
                startActivity(Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                say("Searching now, sir.")
            }
            else -> askAI(c)
        }
    }

    private fun openApp(name: String) {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val app = pm.queryIntentActivities(q, 0)
            .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) }
        val i = app?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        if (i == null) { say("I cannot find $name, sir."); return }
        startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        say("Opening $name, sir.")
    }

    private fun torch(on: Boolean) {
        try {
            val cm = getSystemService(CameraManager::class.java)
            cm.setTorchMode(cm.cameraIdList[0], on)
            say(if (on) "Torch on, sir." else "Torch off, sir.")
        } catch (e: Exception) { say("The torch is unavailable, sir.") }
    }

    private fun vol(d: Int) {
        getSystemService(AudioManager::class.java)
            .adjustStreamVolume(AudioManager.STREAM_MUSIC, d, AudioManager.FLAG_SHOW_UI)
        say("Very good, sir.")
    }

    // ---------- AI fallback (Claude API) ----------
    private fun askAI(q: String) {
        val key = getSharedPreferences("j", MODE_PRIVATE).getString("key", "") ?: ""
        if (key.isBlank()) { say("I have no AI key configured, sir."); return }
        say("One moment, sir.")
        Thread {
            try {
                val body = JSONObject()
                    .put("model", "claude-haiku-5-5")
                    .put("max_tokens", 200)
                    .put("system", "You are Jarvis, a polite British butler AI. Reply in at most two short spoken sentences, no markdown. Address the user as sir.")
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", q)))
                val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.doOutput = true
                c.connectTimeout = 15000
                c.readTimeout = 30000
                c.setRequestProperty("x-api-key", key)
                c.setRequestProperty("anthropic-version", "2023-06-01")
                c.setRequestProperty("content-type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val s = if (c.responseCode < 400) c.inputStream else c.errorStream
                val r = s.bufferedReader().readText()
                val t = JSONObject(r).getJSONArray("content").getJSONObject(0).getString("text")
                h.post { say(t) }
            } catch (e: Exception) {
                h.post { say("I am afraid I could not reach my network, sir.") }
            }
        }.start()
    }

    override fun onDestroy() {
        running = false
        h.removeCallbacksAndMessages(null)
        sr?.destroy()
        tts.shutdown()
        super.onDestroy()
    }
}